# Offline portfolio verification

Status: **PASS (local package)**

- Entry point: `START_HERE.html`; `index.html` redirects to it.
- Interactive demos: 6 standalone HTML files, all self-contained and dependency-free.
- Interactions tested: 12 completed runs (one desktop and one 390 px mobile run for each demo).
- Browser QA: 14 Chrome page runs; 0 console/network exceptions; 0 horizontal overflow failures; minimum visible control target 44 px.
- Universal evidence: 14 PNG files at 2400×1600; 14 SVG source files retained; 6 one-page PDF evidence boards.
- Asset verification: all SVG files parsed as XML; all PNG files decoded and dimension-checked; all evidence PDFs parsed with Poppler.
- Local link crawler: 17 HTML files, 158 local references checked, 0 broken links, 0 visible links to raw SVG files.
- Editorial PDF: 10 A4 pages; selectable text; six readable demo screenshots; ZIP, email and WhatsApp annotations present.
- Screenshots: desktop and 390 px hub; one desktop and one mobile screenshot for every demo.
- Self-contained alternative: `Portfolio_Offline.html` (about 1.6 MB) embeds all six demos and six essential evidence previews. The ZIP remains primary because it also carries all 14 PNGs and six PDF boards.
- Synthetic-data disclosure: present in all six demos and all evidence material.

## Design and slop audit

- Hub surface: Decide/Learn with secondary Explore behavior.
- Site score: 0/10. No tech gradient, generic indigo, feature-tile grid, accent rail, blur, monument stats, icon toppers, center stack, default Inter typography or surface mismatch.
- PDF score: 0/10. It uses a dedicated editorial composition, not a printout of the website.
- Visual review: desktop/mobile hub, six demo screenshots and all ten rendered PDF pages inspected; no visible clipping, overlap, blank page or inconsistent folio found.
- Fable: no executable or configured API was available, so it was not used.

## Local SHA-256 before Drive upload

- `START_HERE.html`: `22a4b6b0ebd224324fedaed805985d5c9c640586a1c006b9cfba28c83ff6e1c2`
- `Portfolio_Offline.html`: `6a126c1077b195f0793cf6c3b1241c9393d64f0b18b76fec39fc1ae4bbdc3136`
- `Nicholas_Mariani_Portfolio.pdf`: `a958be009c1a0a24eb48ef86b19d25e25dc0ed31d5bc82f9025f742f64898157`

Drive upload/download hashes and permission checks are recorded in the external `verification-report.md` after in-place replacement.
