# Fact audit — Nicholas Mariani

Date: 2026-07-16

## Direct hands-on

- Airtable relational systems across multiple business units; lead, application, buyer, UTM and customer-service workflows. Evidence: AEON Airtable node (135 source mentions, Feb 2024–Jun 2026).
- GoHighLevel CRM, calendars, email/SMS, routing and follow-up; ClickFunnels landing/funnel operations. Evidence: Nicholas and ClickFunnels nodes, call sources.
- n8n, Zapier, Make, REST APIs and webhooks for operating workflows. Evidence: n8n node; nightly reconciliation live from 2026-03-07.
- Google Workspace and Sheets automation; master/individual compensation files connected by scripts. Evidence: Google Sheets node.
- Docker/VPS/Cloudflare: self-hosted n8n, Traefik, Redis/RSS services and Cloudflare Tunnel. Evidence: Docker node and local project material.
- Meta advertising operations and technical tracking: Business Manager, Pixel, custom conversions, UTM mapping, funnel diagnosis, Cloudflare/DNS and Google Tag Manager. Evidence: Nicholas and Meta Ads nodes. The sources identify another person as day-to-day media buyer, so Nicholas is not described as the sole or lead media buyer for LDP.
- E-commerce and websites: four owned stores within one year, client/local-business sites, email/SMS conversion and reactivation work. Evidence: private professional profile.
- Oral Pro: internal installment/payment system and process automation are present in the private professional profile; a substantial local CRM analysis repository provides direct technical artifacts and documented verification. The claim that Oral Pro is “one of the largest” in its sector was excluded because no independent source was available in this environment.
- AI-assisted front-end and workflow building: three-day full funnel, custom pages, scripts and integrations under supervision/testing. This is positioned as AI-assisted delivery, not traditional software engineering.

## AI-assisted development

- HTML/CSS/JavaScript and Apps Script for front ends, workflow logic, Google Workspace automation and data systems.
- API integration, data normalization, automation scripts and custom operational tools built with frontier AI and human review.
- Local OralPro-Analysis repository contains extensive Node.js/CommonJS and Python scripts, automated QA documents, ETL/data-normalization work and dashboard/reporting artifacts.

## Working knowledge

- SQL/data modeling, Supabase, chatbot and AI-agent architecture, Redis/Traefik and non-relational database concepts.
- Slack setup and calendar/reminder automation design. A Calendar→Slack automation is supported as a proposed/implemented team workflow, but Nicholas is not credited as the sole coder; it is not presented as a standalone case study.
- Meta Conversions API is not claimed as hands-on in the CV. Local documents discuss CAPI architecture, but the strongest direct evidence supports Pixel, custom conversions and technical tracking rather than a verified production CAPI implementation owned by Nicholas.

## Education / exposure

- Verified course availability in `/mnt/h/Mega/` and AEON course KB: Nate Herk — AI Automation Society Plus; Nick Saraev — Maker School; GMB Crush — AI Ready; Jeff J Hunter — AI Money Group; Dario Vignali — Traffic Academy; Frank Merenda — Copy; Acquisition X; Marketers — Funnel Secrets; Dan Koe; Jeremy Miner.
- Selected CV list is deliberately short. Access/availability does not prove completion, so wording is “selected study includes”, not “completed” or “certified”.
- Video/photo: Adobe Premiere and Photoshop are connected to Nicholas in AEON, and source notes support VSL recording/review and AI video/avatar workflows. Included only as a supporting capability, not a core skill block.

## Certification wording

The requested CCA-F title could not be verified on a live official Anthropic certification page: the guessed Anthropic certifications URL returned 404 and web search was unavailable. To avoid inventing an official credential name, the CV uses the cautious wording: “Currently studying toward Anthropic’s Claude Certified Architect – Foundations (CCA-F) exam; credential not yet earned.” This remains a point requiring official-source confirmation before external use.

## Explicit exclusions

- Looker Studio: removed at Nicholas’s direction and not relied on.
- “Software engineer” / senior developer: excluded; evidence supports AI technical operator / automation builder.
- Sole or lead LDP media buyer: excluded; sources name a separate operating media buyer.
- Production Meta Conversions API ownership: excluded as not sufficiently proven.
- Oral Pro “one of Italy’s largest dental agencies”: excluded pending independent proof.
- Personal causal claim for €2M+ annual revenue: excluded. The CV uses only a cautious organization-level statement and does not attribute revenue causality to Nicholas.
- Course completion and certifications: excluded unless documented.
- Unsupported financial results for stores, funnels or client work: excluded.

## `Can be shown` promise closure

The original portfolio contained six `Can be shown` statements covering 14 deliverables. The redesigned portfolio removes the promise language and links every deliverable to a real offline asset:

| Case | Promised evidence | Offline asset |
|---|---|---|
| Funnel | Sanitized architecture | `evidence/01-funnel-architecture.svg` |
| Funnel | Event map | `evidence/02-funnel-event-map.svg` |
| Funnel | Synthetic workflow | `evidence/03-funnel-workflow.svg` |
| Airtable | Synthetic relational schema | `evidence/04-airtable-schema.svg` |
| Airtable | Field map | `evidence/05-airtable-field-map.svg` |
| Airtable | Example lifecycle | `evidence/06-airtable-lifecycle.svg` |
| Dental | Generalized ETL architecture | `evidence/07-dental-etl.svg` |
| Dental | Synthetic report | `evidence/08-dental-synthetic-report.svg` |
| Docker/VPS | Redacted topology | `evidence/09-docker-vps-topology.svg` |
| Docker/VPS | Synthetic n8n workflow | `evidence/10-n8n-workflow.svg` |
| Meta | Synthetic event map | `evidence/11-meta-event-map.svg` |
| Meta | Synthetic attribution map | `evidence/12-meta-attribution-map.svg` |
| E-commerce | Customer journey | `evidence/13-ecommerce-customer-journey.svg` |
| E-commerce | Original non-client example | `evidence/14-ecommerce-synthetic-example.svg` |

All 14 SVGs state that they are anonymized or synthetic reconstructions based on real delivery and are not production screenshots. The pack index is `evidence/index.html`.
